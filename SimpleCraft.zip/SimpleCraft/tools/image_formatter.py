from PIL import Image 

file = input("image:\n")
image = Image.open(file) 
new_image = image.resize((256,256))
new_image.save(file, format="png", lossless=True)
