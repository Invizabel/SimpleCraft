#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "perlin.h"

int voxelMesh[12288][3];

void mesher()
{
    int old_spawn = 0;
    int spawn = 0;
    float cubePosition[][3] = {{-1.0f,1.0f,-1.0f,},
          {-1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {-1.0f,1.0f,1.0f},
          {-1.0f,1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {-1.0f,1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,1.0},
          {-1.0f,1.0f,1.0f},
          {1.0f,1.0f,1.0f}};

    // calculate spawn and flatten one side
    float xer = 0;
    for (int x = 0; x < 8; x++)
    {
        float yer = 0;
        
        for (int y = 0; y < 8; y++)
        {
            float zer = 0;
            
            for (int z = 0; z < 8; z++)
            {
                for (int i = 0; i < 24; i++)
                {
                    int noise = perlinNoise(xer * 1.1, yer * 1.1, zer  * 1.1);
                    old_spawn = noise;

                    if (spawn < old_spawn)
                    {
                        spawn = old_spawn;
                    }

                    
                }

                zer++;
            }

            yer++;
        }

        xer++;
    }

    // add chunks to array
    int nth = 0;
    xer = 0;
    for (int x = 0; x < 8; x++)
    {
        float yer = 0;
        
        for (int y = 0; y < 8; y++)
        {
            float zer = 0;
            
            for (int z = 0; z < 8; z++)
            {
                for (int i = 0; i < 24; i++)
                {
                    int noise = perlinNoise(xer * 1.1, yer * 1.1, zer  * 1.1);
                    float flatten = (noise / 8);
                    voxelMesh[nth][0] = cubePosition[i][0] + xer * 2;
                    voxelMesh[nth][1] = (cubePosition[i][1] * noise / 8) + flatten;
                    voxelMesh[nth][2] = cubePosition[i][2] + zer * 2;

                    nth++;
                }

                zer++;
            }

            yer++;
        }

        xer++;
    }
}
