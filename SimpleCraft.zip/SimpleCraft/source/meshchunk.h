#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "perlin.h"

int voxelMesh[12288][3];

void mesher()
{
    float cubePosition[][3] = {{-1.0f,1.0f,-1.0f,},
          {-1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {-1.0f,1.0f,1.0f},
          {-1.0f,1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {-1.0f,1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,1.0},
          {-1.0f,1.0f,1.0f},
          {1.0f,1.0f,1.0f}};

    int nth = 0;
    float xer = 0;
    for (int x = 0; x < 8; x++)
    {
        float yer = 0;
        
        for (int y = 0; y < 8; y++)
        {
            float zer = 0;
            
            for (int z = 0; z < 8; z++)
            {
                for (int i = 0; i < 24; i++)
                {
                    int noise = perlinNoise(xer * 1.1, yer * 1.1, zer  * 1.1);
                    voxelMesh[nth][0] = cubePosition[i][0] + xer;
                    voxelMesh[nth][1] = cubePosition[i][1] * noise;
                    voxelMesh[nth][2] = cubePosition[i][2] + zer;

                    nth++;
                }

                zer++;
            }

            yer++;
        }

        xer++;
    }
}
