#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "perlin.h"

extern float voxelMesh[3][24 * 64];

void mesher()
{
    int (*noise)[3] = perlinNoise();

    float cubePosition[][24] = {{-1.0f,1.0f,-1.0f,},
      {-1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {-1.0f,1.0f,1.0f},
      {-1.0f,1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {-1.0f,1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,1.0},
      {-1.0f,1.0f,1.0f},
      {1.0f,1.0f,1.0f}};

    int noises = sizeof(noise);

    int n = 0;
    for (int x = 0; x < noises; x++)
    {
        for (int y = 0; y < noises; y++)
        {
            for (int i = 0; i < 24; i++)
            {
                voxelMesh[0][n] = cubePosition[i][0] * 16 * x;
                voxelMesh[1][n] = cubePosition[i][1] * 16 * y;
                voxelMesh[2][n] = cubePosition[i][2] * 16;
                n++;
            }
        }
    }
}
