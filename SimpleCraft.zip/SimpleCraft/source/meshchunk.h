#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>

extern float voxelMesh[3][24 * 64];

void mesher()
{
    float cubePosition[][24] = {{-1.0f,1.0f,-1.0f,},
      {-1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {-1.0f,1.0f,1.0f},
      {-1.0f,1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {-1.0f,1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,1.0},
      {-1.0f,1.0f,1.0f},
      {1.0f,1.0f,1.0f}};
    
    for (int i = 0; i < 24; i++)
    {
        voxelMesh[0][i] = cubePosition[i][0]*16;
        voxelMesh[1][i] = cubePosition[i][1]*16;
        voxelMesh[2][i] = cubePosition[i][2]*16;
    }
}
