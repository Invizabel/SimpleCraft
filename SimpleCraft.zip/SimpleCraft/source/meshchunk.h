#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "perlin.h"

int voxelMesh[12288][3];

void mesher()
{
    float cubePosition[][3] = {{-1.0f,1.0f,-1.0f,},
          {-1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,1.0f,1.0f},
          {-1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {-1.0f,1.0f,1.0f},
          {-1.0f,1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {1.0f,1.0f,1.0f},
          {1.0f,-1.0f,-1.0f},
          {1.0f,1.0f,-1.0f},
          {-1.0f,1.0f,-1.0f},
          {-1.0f,-1.0f,-1.0f},
          {1.0f,-1.0f,1.0f},
          {-1.0f,-1.0f,1.0},
          {-1.0f,1.0f,1.0f},
          {1.0f,1.0f,1.0f}};

    int nth = 0;
    for (int z = 0; z < 8; z++)
    {
        for (int y = 0; y < 8; y++)
        {
            for (int x = 0; x < 8; x++)
            {
                //float noise = perlinNoise(x, y, z);
                for (int i = 0; i < 24; i++)
                {
                    voxelMesh[nth][0] = cubePosition[i][0] * 2;
                    voxelMesh[nth][1] = cubePosition[i][1];
                    voxelMesh[nth][2] = cubePosition[i][2] * 2;
                    nth++;
                }
            }
        }
    }
}
