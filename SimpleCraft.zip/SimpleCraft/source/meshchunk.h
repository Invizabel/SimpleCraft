#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "perlin.h"

extern float voxelMesh[3][24 * 64];

void mesher()
{
    int (*noise)[3] = perlinNoise();

    float cubePosition[][24] = {{-1.0f,1.0f,-1.0f,},
      {-1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,1.0f,1.0f},
      {-1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {-1.0f,1.0f,1.0f},
      {-1.0f,1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {1.0f,1.0f,1.0f},
      {1.0f,-1.0f,-1.0f},
      {1.0f,1.0f,-1.0f},
      {-1.0f,1.0f,-1.0f},
      {-1.0f,-1.0f,-1.0f},
      {1.0f,-1.0f,1.0f},
      {-1.0f,-1.0f,1.0},
      {-1.0f,1.0f,1.0f},
      {1.0f,1.0f,1.0f}};

    int noises = sizeof(noise);

    int n = 0;
    for (int x = 0; x < noises; x++)
    {
        for (int z = 0; z < noises; z++)
        {
            if (noise[x][0] % 4 == 8 || noise[x][0] % 8 == 0)
            {   
                for (int i = 0; i < 24; i++)
                {
                    
                    voxelMesh[0][i] = cubePosition[i * n][0];
                    voxelMesh[1][i] = cubePosition[i * n][1];
                    voxelMesh[2][i] = cubePosition[i * n][2];
                }
            }

            n++;
        }
    }
}
