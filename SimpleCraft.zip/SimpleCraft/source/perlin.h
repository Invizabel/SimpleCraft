#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define PERLIN_SIZE 256

static int permutation[PERLIN_SIZE];
static int p[PERLIN_SIZE * 2];

void init_permutation() {
    // Initialize permutation table
    for (int i = 0; i < PERLIN_SIZE; i++)
    {
        permutation[i] = i;
    }

    // Shuffle the permutation table
    for (int i = PERLIN_SIZE - 1; i > 0; i--)
    {
        int j = rand() % (i + 1);
        int temp = permutation[i];
        permutation[i] = permutation[j];
        permutation[j] = temp;
    }

    // Copy permutation table for faster lookup
    for (int i = 0; i < PERLIN_SIZE; i++) {
        p[PERLIN_SIZE + i] = p[i] = permutation[i];
    }
}

// Fade function as defined by Ken Perlin
static float fade(float t)
{
    return t * t * t * (t * (t * 6 - 15) + 10);
}

// Linear interpolation
static float lerp(float t, float a, float b)
{
    return a + t * (b - a);
}

// Gradient function
static float grad(int hash, float x, float y, float z)
{
    int h = hash & 15;           // Convert low 4 bits of hash code
    float u = h < 8 ? x : y;     // into 12 gradient directions.
    float v = h < 4 ? y : h == 12 || h == 14 ? x : z;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

float perlin(float x, float y, float z)
{
    int X = (int)floor(x) & 255;                  // Find unit cube that
    int Y = (int)floor(y) & 255;                  // contains point.
    int Z = (int)floor(z) & 255;
    x -= floor(x);                                // Find relative x, y, z
    y -= floor(y);                                // of point in cube.
    z -= floor(z);
    float u = fade(x);                            // Compute fade curves
    float v = fade(y);                            // for each of x, y, z.
    float w = fade(z);
    int A = p[X] + Y;                             // Hash coordinates of
    int AA = p[A] + Z;                            // the 8 cube corners,
    int AB = p[A + 1] + Z;
    int B = p[X + 1] + Y;
    int BA = p[B] + Z;
    int BB = p[B + 1] + Z;

    return lerp(w, lerp(v, lerp(u, grad(p[AA], x, y, z),      // and add
                                   grad(p[BA], x - 1, y, z)), // blended
                           lerp(u, grad(p[AB], x, y - 1, z),  // results
                                   grad(p[BB], x - 1, y - 1, z))), // from 8
                   lerp(v, lerp(u, grad(p[AA + 1], x, y, z - 1), // corners
                                   grad(p[BA + 1], x - 1, y, z - 1)), // of cube
                           lerp(u, grad(p[AB + 1], x, y - 1, z - 1),
                                   grad(p[BB + 1], x - 1, y - 1, z - 1))));
}

int int_perlin(float x, float y, float z) {
    // Scale the output of the Perlin noise to be in the range of 0-255
    // and convert to an integer. Perlin noise naturally ranges from -1 to 1.
    float noise_value = perlin(x, y, z);
    int scaled_value = (int)((noise_value + 1.0f) * 127.5f); // Scale to 0-255
    return scaled_value;
}

int perlinNoise(float x, float y, float z)
{
    srand((unsigned int)time(NULL)); // Initialize random seed
    init_permutation();
    int result = int_perlin(x, y, z);
    return result;
}
