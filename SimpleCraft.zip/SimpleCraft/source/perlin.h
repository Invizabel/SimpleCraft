#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define PERLIN_SIZE 256

static int permutation[PERLIN_SIZE];
static int p[PERLIN_SIZE * 2];

void init_permutation()
{
    // Initialiye permutation table
    for (int i = 0; i < PERLIN_SIZE; i++)
    {
        permutation[i] = i;
    }

    // Shuffle the permutation table
    for (int i = PERLIN_SIZE - 1; i > 0; i--)
    {
        int j = rand() % (i + 1);
        int temp = permutation[i];
        permutation[i] = permutation[j];
        permutation[j] = temp;
    }

    // Copy permutation table for faster lookup
    for (int i = 0; i < PERLIN_SIZE; i++)
    {
        p[PERLIN_SIZE + i] = p[i] = permutation[i];
    }
}

float fade(float t) {
    return t * t * t * (t * (t * 6 - 15) + 10);
}

float lerp(float t, float a, float b) {
    return a + t * (b - a);
}

float grad(int hash, float x, float y) {
    int h = hash & 7;
    float u = h < 4 ? x : y;
    float v = h < 4 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -2 * v : 2 * v);
}

float perlin2D(float x, float y) {
    int X = (int)floor(x) & 255;
    int Y = (int)floor(y) & 255;
    x -= floor(x);
    y -= floor(y);
    float u = fade(x);
    float v = fade(y);
    int A = p[X] + Y, AA = p[A], AB = p[A + 1];
    int B = p[X + 1] + Y, BA = p[B], BB = p[B + 1];
    return lerp(v, lerp(u, grad(p[AA], x, y), grad(p[BA], x - 1, y)),
                    lerp(u, grad(p[AB], x, y - 1), grad(p[BB], x - 1, y - 1)));
}

int (*perlinNoise())[3]
{
    // generate random seed
    char defaultSeed[] = "Party Time";
    int defaultSeedInt = strtoull(defaultSeed, NULL, 64);
    srand(defaultSeedInt);
    init_permutation();
    
    int SIZE = 64;
    int noiseCount = 0;
    int (*chunkArray)[3] = malloc(SIZE * SIZE * sizeof(int[3]));
    
    for (int y = 0; y < SIZE; y++)
    {
        for (int x = 0; x < SIZE; x++)
        {
            chunkArray[noiseCount][0] = x;
            chunkArray[noiseCount][1] = y;
            chunkArray[noiseCount][2] = round(perlin2D(x, y));
            noiseCount++;
        }
    }

    return chunkArray;
}
